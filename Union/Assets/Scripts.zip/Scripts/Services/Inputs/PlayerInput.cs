using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Union.Services.Inputs
{
    [RequireComponent(typeof(CharacterController3D))]
    public sealed class PlayerInput : MonoBehaviour
    {
        [SerializeField]
        CharacterController3D _controller;

        PlayerTwoAxisAction _move;
        PlayerTwoAxisAction _camera;

        PlayerAction _jump;
        PlayerAction _attack;

        List<IActionProvider> _providers;

        private void Awake()
        {
            _move = new PlayerTwoAxisAction("Horizontal", "Vertical", 0.1f);

            _jump = new PlayerAction("Jump");
            _attack = new PlayerAction("Attack");

            _providers = new List<IActionProvider>()
            {
                _move,
                _jump,
                _attack,
            };
        }

        private void Update()
        {
            foreach (var provider in _providers)
                provider.Update();

            float x = _move.X;
            float y = _move.Y;

            _controller.Move(x, y);

            if (_jump.WasPressed)
                _controller.Jump();

            if (_attack.WasPressed)
                _controller.Attack();
        }
    }
}
