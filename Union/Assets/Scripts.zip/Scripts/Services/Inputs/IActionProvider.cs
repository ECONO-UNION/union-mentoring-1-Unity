using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Union.Services.Inputs
{
    public interface IActionProvider
    {
        void Update();
    }
}
