using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Union
{
    [RequireComponent(typeof(CharacterController))]
    public sealed class CharacterController3D : MonoBehaviour
    {
        [SerializeField]
        CharacterController _characterController;

        [SerializeField]
        float _speed = 10;
        [SerializeField]
        float _jumpHeight = 10;

        [SerializeField]
        float _gravity = 5;

        Vector3 _horizontal;
        Vector3 _vertical;

        public void Move(float x, float y)
        {
            var direction = transform.TransformDirection(new Vector3(x, 0, y));
            _horizontal = direction *  _speed * Time.deltaTime;
        }

        public void Jump()
        {
            _vertical = transform.up * _jumpHeight * Time.deltaTime;
        }

        public void Attack()
        {
            
        }

        private void Update()
        {
            _vertical -= transform.up * _gravity * Time.deltaTime;
            if (Mathf.Approximately(_vertical.sqrMagnitude, 0f))
            {
                _vertical = Vector3.zero;
            }

            var movement = _horizontal + _vertical;
            _characterController.Move(movement);

            _horizontal = Vector3.zero;
            _vertical = Vector3.zero;
        }
    }
}
